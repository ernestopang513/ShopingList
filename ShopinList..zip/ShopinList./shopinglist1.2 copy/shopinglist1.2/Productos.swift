//
//  Productos.swift
//  shopinglist1.2
//
//  Created by Ernesto Pang on 9/22/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import Foundation
struct Productos{
    var nombre: String
    var precio: Double
    var informacion: String
    var cantidad: Int
    var imagen: String
}
