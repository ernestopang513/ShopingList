//
//  SecondViewController.swift
//  shopinglist1.2
//
//  Created by Ernesto Pang on 9/22/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
protocol transferirDatos {
    func transferir(nombre: String, precio: Double, infomacion: String,cantidad: Int, imagen: String)
}

class SecondViewController: UIViewController {
    
    
    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet var aviso: UIView!
    var delegate : transferirDatos?
    var conteo = 0
    var datos: Int = 0
    var shopinglist2 = [Productos]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        aviso.layer.cornerRadius = 10
        label3.text = "\(conteo)"
        label2.text = shopinglist2[datos].nombre
        label.text = shopinglist2[datos].informacion
        let url = URL( string: shopinglist2[datos].imagen )
        let data = try? Data(contentsOf: url!)
        let image = UIImage(data: data!)
        imagen.image = image
        imagen.layer.cornerRadius = 30
        imagen.layer.borderWidth = 3
        imagen.layer.masksToBounds = true
        
    }
    
    
    
    @IBAction func compra(_ sender: UIButton) {
        if conteo > 0{
            shopinglist2[datos].cantidad = conteo
            delegate?.transferir( nombre: shopinglist2[datos].nombre, precio: shopinglist2[datos].precio, infomacion: shopinglist2[datos].informacion, cantidad: shopinglist2[datos].cantidad , imagen:  shopinglist2[datos].imagen)
            
            
            animateIn()
            conteo = 0
            label3.text = "\(conteo)"
            
        }
        
    }
    
    @IBAction func mas(_ sender: UIButton) {
        conteo = conteo + 1
        label3.text = "\(conteo)"
    }
    @IBOutlet weak var label3: UILabel!
    
    @IBAction func menos(_ sender: UIButton) {
        conteo = conteo - 1
        label3.text = "\(conteo)"
    }
    
    @IBOutlet weak var label2: UILabel!
    
    @IBOutlet weak var label: UILabel!
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    func animateIn() {
        self.view.addSubview(aviso)
        aviso.center = self.view.center
        
        aviso.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        aviso.alpha = 0
        UIView.animate(withDuration: 0.4){
            self.aviso.alpha = 0.85
            self.aviso.transform = CGAffineTransform.identity
        }
    }
    func animeteOut(){
        UIView.animate(withDuration: 0.3, animations:{
            self.aviso.transform = CGAffineTransform.init(scaleX: 1.3 ,y: 1.3 )
            self.aviso.alpha = 0
            //self.efectovisual.effect = nil
        } ){(success: Bool) in
            self.aviso.removeFromSuperview()
        }
    }
    
    
    @IBAction func outPopup(_ sender: UIButton) {
        animeteOut()
    }
}

