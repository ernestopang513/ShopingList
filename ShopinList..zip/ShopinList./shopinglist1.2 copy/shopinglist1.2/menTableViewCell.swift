//
//  menTableViewCell.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/30/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class menTableViewCell: UITableViewCell {
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var labelCell: UILabel!
    var shopinglist = [Productos]()
    var carrito = [Productos]()
    override func awakeFromNib() {
        super.awakeFromNib()
        shopinglist.append(Productos(nombre: "Nave espacial", precio: 1000, informacion: "Nave espacial con capacidad de viajes interdimencionales", cantidad: 0))
        shopinglist.append(Productos(nombre: "Computadora cuantica", precio: 799.99, informacion: "Computadora que usa cubits en lugar de bits", cantidad: 0))
        shopinglist.append(Productos(nombre: "Kriptonita", precio: 10000, informacion: "Super eficiente para matar super hombres de acero", cantidad: 0))
        shopinglist.append(Productos(nombre: "Corazon", precio: 599.99, informacion: "Util para la morra fria que no tiene sentimientos", cantidad: 0))
        shopinglist.append(Productos(nombre: "Piedra filosofal", precio: 99999.99, informacion: "?????", cantidad: 0))        // Initialization code
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shopinglist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! menTableViewCell
        cell.labelCell.text = shopinglist[indexPath.row].nombre
        cell.imageCell.image = UIImage(named: shopinglist[indexPath.row].nombre)
        return cell
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
 }
