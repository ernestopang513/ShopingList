//
//  ViewController.swift
//  shopinglist1.2
//
//  Created by Ernesto Pang on 9/22/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource , UITableViewDelegate, transferirDatos{

    
    
    func transferir(nombre: String, precio: Double, infomacion: String,cantidad: Int,imagen: String) {
        if carrito.count == 0 && cantidad != 0{
            carrito.append(Productos(nombre: nombre, precio: precio, informacion: infomacion, cantidad: cantidad, imagen: imagen))
        }else{
            var i = 0
            for item in carrito{
                if item.nombre == nombre{
                    carrito[i].cantidad = item.cantidad + cantidad
                    i = -1
                    break
                }
                i += 1
            }
            if i != -1{
                carrito.append(Productos(nombre: nombre, precio: precio, informacion: infomacion, cantidad: cantidad, imagen: imagen))
            }
        }
        
        
    }
    
    
    
    @IBOutlet weak var tabla: UITableView!
    var shopinglist = [Productos]()
    var carrito = [Productos]()
    override func viewDidLoad() {
        super.viewDidLoad()
        shopinglist.append(Productos(nombre: "Nave espacial", precio: 1000, informacion: "Nave espacial con capacidad de viajes interdimencionales", cantidad: 0, imagen: "https://2.bp.blogspot.com/-SY0VoI5CPWs/WuJt4Uc5XHI/AAAAAAAABKg/4AN8kz80PbIoEfYwJlQBeps_elMMRDJnQCLcBGAs/s1600/proxima-centauri1.png"))
        shopinglist.append(Productos(nombre: "Computadora cuantica", precio: 799.99, informacion: "Computadora que usa cubits en lugar de bits", cantidad: 0, imagen: "https://media.metrolatam.com/2018/01/30/nasacuc3a1ntica660x595-1200x600.jpg"))
        shopinglist.append(Productos(nombre: "Kriptonita", precio: 10000, informacion: "Super eficiente para matar super hombres de acero", cantidad: 0,  imagen: "https://static.turbosquid.com/Preview/2016/04/05__15_41_14/Kryptonite_SQRSignature_0000.jpg64fc5dffa971454185f6cb4d0b2ba610Original.jpg14f196c6-95ee-4546-acb3-576dfcaab783Default.jpg"))
        shopinglist.append(Productos(nombre: "Corazon", precio: 599.99, informacion: "Util para la morra fria que no tiene sentimientos", cantidad: 0,  imagen: "https://cualesel.net/wp-content/uploads/cual-es-la-funcion-del-corazon-humano1-e1442401585583.jpg"))
        shopinglist.append(Productos(nombre: "Piedra filosofal", precio: 99999.99, informacion: "?????", cantidad: 0,  imagen: "https://donovanrocester.files.wordpress.com/2017/02/fluorite-fluorspar-violet-glass-gloss-pink-1598490.jpg"))
        
            // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func unwindView (segue: UIStoryboardSegue){
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shopinglist.count
    }
    func colorForIndex(index: Int) -> UIColor{
        let itemCount = shopinglist.count - 1
        let color = (CGFloat(index) / CGFloat(itemCount)) * 0.6
        return UIColor(red: 1.0, green: color, blue: 0.0, alpha: 1.0)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda" ,for: indexPath)
        cell.textLabel?.text = shopinglist[indexPath.row].nombre
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "secondView"{
            let indexPath = tabla.indexPathForSelectedRow
            let destination = segue.destination as! SecondViewController
            destination.shopinglist2 = shopinglist
            destination.datos = (indexPath?.row)!
            destination.delegate = self//.datos = shopinglist[(indexPath?.row)!].informacion
            //destination.shopinglist2 = shopinglist
            //destination.delegate = self
        }
        if segue.identifier == "thirdView"{
            let destination2 = segue.destination as! ThirdViewController
            destination2.carrito2 = carrito
            
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        // Dispose of any resources that can be recreated.
    }}


