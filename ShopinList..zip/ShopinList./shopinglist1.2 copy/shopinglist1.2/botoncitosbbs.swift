//
//  botoncitosbbs.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/30/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class botoncitosbbs: UIButton {
    override func awakeFromNib() {
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.blue.cgColor
        layer.cornerRadius = 5.0
        let shake = CABasicAnimation(keyPath: "position")
        shake.duration = 0.1
        shake.repeatCount = 2
        shake.autoreverses = true
        
        let fromPoint = CGPoint(x: center.x - 5, y:center.y)
        let fromValue = NSValue(cgPoint: fromPoint)
        
        let toPoint = CGPoint(x: center.x + 5, y: center.y)
        let toValue = NSValue(cgPoint: toPoint)
        
        shake.fromValue = fromValue
        shake.toValue = toValue
        
    
        layer.add(shake, forKey: nil)


    }}
