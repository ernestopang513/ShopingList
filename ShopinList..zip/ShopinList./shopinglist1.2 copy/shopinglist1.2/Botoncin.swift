//
//  Botoncin.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/29/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class Botoncin: UIButton {
    override func awakeFromNib() {
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.black.cgColor
        layer.cornerRadius = 9
        let shake = CABasicAnimation(keyPath: "position")
        shake.duration = 2
        shake.repeatCount = 2
        shake.autoreverses = true
        
        let fromPoint = CGPoint(x: center.x - 5, y:center.y)
        let fromValue = NSValue(cgPoint: fromPoint)
        
        let toPoint = CGPoint(x: center.x + 5, y: center.y)
        let toValue = NSValue(cgPoint: toPoint)
        
        shake.fromValue = fromValue
        shake.toValue = toValue
        
        
        
        layer.add(shake, forKey: nil)
    }}

