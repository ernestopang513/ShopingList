//
//  Label2.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/30/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class Label2: UILabel {

  
    override func awakeFromNib() {
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.black.cgColor
        layer.cornerRadius = 5.0

        
    }
}
