//
//  Labels.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/30/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class Labels: UILabel {

    override func awakeFromNib() {
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.blue.cgColor
        layer.cornerRadius = 5.0
        
        
        
    }}


