//
//  menuTableViewController.swift
//  shopinglist1.2
//
//  Created by user143950 on 9/30/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class menuTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        weak var imageCell: UIImageView!
        weak var labelCell: UILabel!


    }}
